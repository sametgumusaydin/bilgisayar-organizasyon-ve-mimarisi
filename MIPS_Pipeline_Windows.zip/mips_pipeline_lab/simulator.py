from dataclasses import dataclass
import re

@dataclass
class Instruction:
    op: str
    rd: str = ''
    rs: str = ''
    rt: str = ''
    imm: int = 0
    target: int = -1
    text: str = ''
    pc: int = -1

    @property
    def sources(self):
        if self.op in ('add','sub','and','or','beq'): return [self.rs,self.rt]
        if self.op in ('addi','lw'): return [self.rs]
        if self.op == 'sw': return [self.rs,self.rt]
        return []
    @property
    def dest(self):
        return self.rd if self.op in ('add','sub','and','or','addi','lw') else ''

NOP = Instruction('nop', text='nop')

def parse(source):
    labels={}; lines=[]
    for raw in source.splitlines():
        line=raw.split('#')[0].strip()
        if not line: continue
        while ':' in line:
            label, line=line.split(':',1)
            label=label.strip()
            if not re.fullmatch(r'[A-Za-z_]\w*',label): raise ValueError('Geçersiz etiket: '+label)
            if label in labels: raise ValueError('Tekrarlanan etiket: '+label)
            labels[label]=len(lines); line=line.strip()
        if line: lines.append(line)
    out=[]
    for pc,line in enumerate(lines):
        parts=[x for x in re.split(r'[\s,()]+',line) if x]
        op=parts[0].lower(); a=parts[1:]
        def reg(x):
            if not re.fullmatch(r'\$[a-zA-Z0-9]+',x): raise ValueError('Geçersiz register: '+x)
            return x.lower()
        if op in ('add','sub','and','or') and len(a)==3:
            ins=Instruction(op,rd=reg(a[0]),rs=reg(a[1]),rt=reg(a[2]))
        elif op=='addi' and len(a)==3:
            ins=Instruction(op,rd=reg(a[0]),rs=reg(a[1]),imm=int(a[2],0))
        elif op=='lw' and len(a)==3:
            ins=Instruction(op,rd=reg(a[0]),rs=reg(a[2]),imm=int(a[1],0))
        elif op=='sw' and len(a)==3:
            ins=Instruction(op,rt=reg(a[0]),rs=reg(a[2]),imm=int(a[1],0))
        elif op=='beq' and len(a)==3:
            if a[2] not in labels: raise ValueError('Bilinmeyen etiket: '+a[2])
            ins=Instruction(op,rs=reg(a[0]),rt=reg(a[1]),target=labels[a[2]])
        elif op=='nop' and not a: ins=Instruction(op)
        else: raise ValueError('Desteklenmeyen komut: '+line)
        ins.text=line; ins.pc=pc; out.append(ins)
    return out

class Simulator:
    def __init__(self, source, registers=None, memory=None, forwarding=True, predictor='not_taken'):
        self.program=parse(source)
        self.reg={f'$t{i}':0 for i in range(10)}
        self.reg.update({f'$s{i}':0 for i in range(8)})
        self.reg['$zero']=0
        self.reg.update(registers or {})
        self.mem=dict(memory or {})
        self.forwarding=forwarding
        if predictor not in ('not_taken','taken','two_bit'): raise ValueError('Tahminci geçersiz')
        self.predictor=predictor; self.counters={}
        self.pc=0; self.stages=[None]*5; self.cycles=0; self.retired=0
        self.stalls=0; self.flushes=0; self.branches=0; self.mispredictions=0
        self.history=[]; self.events=[]
    def value(self,r): return 0 if r=='$zero' else self.reg.get(r,0)
    def predict(self,ins):
        if self.predictor=='taken': return True
        if self.predictor=='not_taken': return False
        return self.counters.get(ins.pc,1)>=2
    def step(self):
        if self.pc>=len(self.program) and not any(self.stages): return False
        if self.cycles>=1000: raise RuntimeError('1000 çevrim sınırı (sonsuz döngü olabilir)')
        old=self.stages; self.cycles+=1; ev=[]
        # WB commits before ID reads; results forwarded from old MEM/WB and EX/MEM.
        wb=old[4]
        if wb:
            ins=wb['ins']; self.retired+=1
            if ins.dest and ins.dest!='$zero': self.reg[ins.dest]=wb['result']
        self.reg['$zero']=0
        # MEM: memory side effects
        mem=None
        if old[3]:
            x=old[3].copy(); ins=x['ins']
            if ins.op=='lw': x['result']=self.mem.get(x['alu'],0)
            if ins.op=='sw': self.mem[x['alu']]=x['store']
            mem=x
        # EX: bypass EX/MEM ALU values or MEM/WB result
        ex=None; branch_redirect=None
        if old[2]:
            x=old[2].copy(); ins=x['ins']
            def operand(r):
                if not r: return 0
                if self.forwarding and old[3] and old[3]['ins'].dest==r and r!='$zero' and old[3]['ins'].op!='lw':
                    ev.append('Forward EX/MEM → '+r); return old[3]['alu']
                if self.forwarding and old[4] and old[4]['ins'].dest==r and r!='$zero':
                    ev.append('Forward MEM/WB → '+r); return old[4]['result']
                return x['vals'].get(r,0)
            a=operand(ins.rs); b=operand(ins.rt)
            if ins.op=='add': x['alu']=a+b
            elif ins.op=='sub': x['alu']=a-b
            elif ins.op=='and': x['alu']=a&b
            elif ins.op=='or': x['alu']=a|b
            elif ins.op=='addi': x['alu']=a+ins.imm
            elif ins.op in ('lw','sw'): x['alu']=a+ins.imm
            elif ins.op=='beq':
                taken=a==b; self.branches+=1
                if self.predictor=='two_bit':
                    self.counters[ins.pc]=max(0,min(3,self.counters.get(ins.pc,1)+(1 if taken else -1)))
                if taken!=x['predicted']:
                    self.mispredictions+=1; branch_redirect=ins.target if taken else ins.pc+1
                    ev.append('Yanlış branch tahmini → flush')
            if ins.op=='sw': x['store']=b
            if ins.op not in ('lw','sw','beq','nop'): x['result']=x['alu']
            ex=x
        # ID: load-use always stalls; without bypass wait until producer has committed
        stall=False
        if old[1] and branch_redirect is None:
            ins=old[1]['ins']
            for pos in (2,3):
                prod=old[pos]
                if prod and prod['ins'].dest and prod['ins'].dest!='$zero' and prod['ins'].dest in ins.sources:
                    if not self.forwarding or (pos==2 and prod['ins'].op=='lw'):
                        stall=True; break
        nxt=[None]*5; nxt[4]=mem; nxt[3]=ex
        if branch_redirect is not None:
            self.flushes+=sum(bool(old[i]) for i in (0,1))
            self.pc=branch_redirect
        elif stall:
            self.stalls+=1; ev.append('Stall: RAW / load-use')
            nxt[1]=old[1]; nxt[0]=old[0]
        else:
            if old[1]:
                x=old[1].copy(); ins=x['ins']
                x['vals']={r:self.value(r) for r in ins.sources}
                nxt[2]=x
            nxt[1]=old[0]
        if not stall:
            if 0<=self.pc<len(self.program):
                ins=self.program[self.pc]; pred=self.predict(ins) if ins.op=='beq' else False
                nxt[0]={'ins':ins,'predicted':pred}
                self.pc=ins.target if ins.op=='beq' and pred else self.pc+1
        self.stages=nxt
        self.events.append('; '.join(ev) or '-')
        self.history.append([self.cycles]+[(x['ins'].text if x else '-') for x in nxt]+[self.events[-1]])
        return True
    def run(self):
        while self.step(): pass
        return self
    def summary(self):
        return {'cycles':self.cycles,'instructions':self.retired,'cpi':round(self.cycles/self.retired,3) if self.retired else 0,
                'stalls':self.stalls,'flushes':self.flushes,'branches':self.branches,'mispredictions':self.mispredictions}
