import tkinter as tk
from tkinter import ttk, messagebox
from simulator import Simulator

EXAMPLE='''# Register başlangıç değerlerini sağdaki alandan değiştirin
lw $t0, 0($s1)
add $t2, $t0, $t3
sub $t4, $t2, $t5
beq $t4, $zero, TARGET
or $t6, $t1, $t2
TARGET:
and $t7, $t2, $t3
'''
root=tk.Tk(); root.title('MIPS 5-Stage Pipeline Laboratuvarı'); root.geometry('1250x800')
top=ttk.Frame(root,padding=10);top.pack(fill='x')
ttk.Label(top,text='MIPS Pipeline Simülatörü',font=('Arial',17,'bold')).pack(anchor='w')
settings=ttk.Frame(top);settings.pack(fill='x',pady=8)
forward=tk.BooleanVar(value=True); ttk.Checkbutton(settings,text='Forwarding açık',variable=forward).pack(side='left',padx=8)
predictor=tk.StringVar(value='not_taken');ttk.Label(settings,text='Branch predictor:').pack(side='left')
ttk.Combobox(settings,textvariable=predictor,values=['not_taken','taken','two_bit'],state='readonly',width=15).pack(side='left',padx=8)
inputs=ttk.Panedwindow(root,orient='horizontal');inputs.pack(fill='both',expand=True,padx=10)
left=ttk.Frame(inputs);right=ttk.Frame(inputs);inputs.add(left,weight=3);inputs.add(right,weight=1)
ttk.Label(left,text='MIPS programı').pack(anchor='w');code=tk.Text(left,height=13,font=('DejaVu Sans Mono',11));code.pack(fill='both',expand=True);code.insert('1.0',EXAMPLE)
ttk.Label(right,text='Başlangıç register değerleri (bir satıra $t1=5)').pack(anchor='w')
regs=tk.Text(right,height=9,font=('DejaVu Sans Mono',10));regs.pack(fill='both',expand=True)
regs.insert('1.0','$s1=100\n$t1=3\n$t3=5\n$t5=12')
ttk.Label(right,text='Bellek değerleri (adres=değer)').pack(anchor='w')
memory=tk.Text(right,height=5,font=('DejaVu Sans Mono',10));memory.pack(fill='both',expand=True);memory.insert('1.0','100=7')
bar=ttk.Frame(root,padding=8);bar.pack(fill='x')
status=tk.StringVar(value='Başlat butonuna basın.');ttk.Label(bar,textvariable=status).pack(side='right')
cols=('Cycle','IF','ID','EX','MEM','WB','Olay')
tree=ttk.Treeview(root,columns=cols,show='headings',height=13)
for col in cols:tree.heading(col,text=col);tree.column(col,width=75 if col=='Cycle' else 195 if col=='Olay' else 145,stretch=True)
tree.pack(fill='both',expand=True,padx=10,pady=5)
output=tk.Text(root,height=5,font=('DejaVu Sans Mono',10));output.pack(fill='x',padx=10,pady=8)
sim=None

def parse_assign(text):
    result={}
    for line in text.splitlines():
        line=line.split('#')[0].strip()
        if not line:continue
        k,v=line.split('=',1);result[k.strip()]=int(v.strip(),0)
    return result

def refresh():
    for item in tree.get_children():tree.delete(item)
    for row in sim.history:tree.insert('', 'end', values=row)
    if tree.get_children():tree.see(tree.get_children()[-1])
    output.delete('1.0','end')
    output.insert('end','Özet: '+str(sim.summary())+'\n')
    output.insert('end','Register: '+str({k:v for k,v in sorted(sim.reg.items()) if v})+'\n')
    output.insert('end','Bellek: '+str(sim.mem))
    status.set('Çevrim '+str(sim.cycles))

def start():
    global sim
    try:
        r=parse_assign(regs.get('1.0','end'));m=parse_assign(memory.get('1.0','end'))
        sim=Simulator(code.get('1.0','end'),r,{int(k,0):v for k,v in m.items()},forward.get(),predictor.get())
        refresh()
    except Exception as e:messagebox.showerror('Hata',str(e))
def step():
    if sim is None:start()
    if sim is None:return
    try:sim.step();refresh()
    except Exception as e:messagebox.showerror('Hata',str(e))
def run():
    if sim is None:start()
    if sim is None:return
    try:sim.run();refresh()
    except Exception as e:messagebox.showerror('Hata',str(e))
ttk.Button(bar,text='Başlat / Sıfırla',command=start).pack(side='left',padx=5)
ttk.Button(bar,text='1 çevrim ilerle',command=step).pack(side='left',padx=5)
ttk.Button(bar,text='Programı çalıştır',command=run).pack(side='left',padx=5)
root.mainloop()
