# MIPS 5 Aşamalı Pipeline Laboratuvarı

## Kurulum
Ubuntu 22.04 için:

```bash
sudo apt update
sudo apt install python3 python3-tk
cd mips_pipeline_lab
python3 app.py
```

Windows için Python 3.10+ kurun ve `python app.py` çalıştırın. Tkinter gereklidir.

## Aşama 1 — Komut yürütme
1. Program alanına `add $t0, $t1, $t2` yazın.
2. Register alanına `$t1=15` ve `$t2=25` girin.
3. **Başlat / Sıfırla** ardından **1 çevrim ilerle** düğmesine beş kez basın.
4. IF, ID, EX, MEM, WB sütunlarını gözlemleyin; `$t0=40` olduğunu doğrulayın.
5. `lw $t0, 8($s1)` için `$s1=100`, bellek `108=75` kullanın. Sonucu inceleyin.
6. `sw $t0, 8($s1)` için `$t0=42`, `$s1=100` kullanın. Bellekte `108=42` olduğunu doğrulayın.

## Aşama 2 — Hazard ve forwarding
Program:

```mips
lw $t0, 0($s1)
add $t2, $t0, $t3
sub $t4, $t2, $t5
```

Register: `$s1=100`, `$t3=5`, `$t5=12`; bellek `100=7`.

1. Forwarding açıkken çalıştırın; stall sayısını, toplam çevrimi ve CPI değerini yazın.
2. **Başlat / Sıfırla** öncesinde forwarding'i kapatıp aynı programı çalıştırın.
3. Neden daha çok stall oluştuğunu açıklayın.
4. `lw` ile `add` arasına bağımsız komut koyup tekrar deneyin.

## Aşama 3 — Branch prediction
Program:

```mips
addi $t0, $zero, 1
beq $t0, $t0, TARGET
addi $t1, $zero, 99
TARGET:
addi $t2, $zero, 7
```

1. `not_taken`, `taken` ve `two_bit` modlarını ayrı ayrı çalıştırın.
2. Yanlış tahmin ve flush sayılarını karşılaştırın.
3. `$t1` neden 0 kaldı? Açıklayın.
4. `beq` koşulunu gerçekleşmeyecek biçimde değiştirip yeniden deneyin.

## Öğrenci raporu
Her aşama için program, başlangıç register/bellek değerleri, çevrim tablosu, stall, flush, toplam çevrim, tamamlanan komut sayısı, CPI ve kısa yorum ekleyin. Forwarding açık/kapalı sonuçlarını karşılaştırın.

## Desteklenen komutlar
`add rd,rs,rt`, `sub`, `and`, `or`, `addi rd,rs,imm`, `lw rd,offset(rs)`, `sw rt,offset(rs)`, `beq rs,rt,LABEL`, `nop`.

## Model varsayımları ve sınırlar
- Eğitim amaçlı beş aşamalı, tek komut genişlikli, sıralı pipeline.
- Branch EX aşamasında çözülür; yanlış tahmin durumunda IF ve ID iptal edilir.
- Forwarding EX/MEM ve MEM/WB kaynaklarından EX'e yapılır; load-use için bir stall gerekir.
- Bellek bir Python sözlüğüdür; bellek gecikmesi, cache, exception, signed 32-bit taşma ve tam MIPS ISA modellenmez.
- Register adları metin olarak kullanılır; `\$zero` sabit 0'dır. Bellek adresleri byte adresi olarak ele alınır ancak hizalama kontrolü yoktur.
- Her program en fazla 1000 çevrim çalıştırılır.
- Grafik arayüzü açılmazsa `python3 -m unittest -v` ile çekirdek testlerini çalıştırabilirsiniz.
