import unittest
from simulator import Simulator
class TestPipeline(unittest.TestCase):
    def test_load_use(self):
        src='lw $t0, 0($s1)\nadd $t2, $t0, $t3'
        x=Simulator(src,{'$s1':100,'$t3':5},{100:7}).run()
        self.assertEqual(x.reg['$t2'],12);self.assertEqual(x.stalls,1)
    def test_forward(self):
        src='add $t0, $t1, $t2\nsub $t3, $t0, $t4'
        x=Simulator(src,{'$t1':8,'$t2':5,'$t4':3}).run()
        self.assertEqual(x.reg['$t3'],10);self.assertEqual(x.stalls,0)
        y=Simulator(src,{'$t1':8,'$t2':5,'$t4':3},forwarding=False).run()
        self.assertEqual(y.reg['$t3'],10);self.assertGreater(y.stalls,0)
    def test_branch(self):
        src='addi $t0, $zero, 1\nbeq $t0, $t0, END\naddi $t1, $zero, 99\nEND:\naddi $t2, $zero, 7'
        x=Simulator(src).run()
        self.assertEqual(x.reg['$t1'],0);self.assertEqual(x.reg['$t2'],7)
        self.assertEqual(x.mispredictions,1)
    def test_store(self):
        x=Simulator('addi $t0, $zero, 9\nsw $t0, 0($s1)\nlw $t2, 0($s1)',{'$s1':100}).run()
        self.assertEqual(x.mem[100],9);self.assertEqual(x.reg['$t2'],9)
if __name__=='__main__':unittest.main()
