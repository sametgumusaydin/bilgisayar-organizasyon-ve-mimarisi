import tkinter as tk
from tkinter import ttk,messagebox
from simulator import Pipeline

EXAMPLE='''# Başlangıç: $s1=100, $t3=5, $t5=12; bellek[100]=7
lw  $t0, 0($s1)
add $t2, $t0, $t3
sub $t4, $t2, $t5
sw  $t4, 4($s1)
'''
class App(tk.Tk):
    def __init__(self):
        super().__init__();self.title('MIPS Pipeline — Aşama 3 | Windows + Ubuntu');self.geometry('1200x790');self.configure(bg='#edf2f7')
        self.sim=None;self.pos=0;self.running=False
        top=ttk.Frame(self,padding=10);top.pack(fill='x')
        ttk.Label(top,text='MIPS 5-Aşamalı Pipeline | Aşama 3',font=('Arial',17,'bold')).pack(side='left')
        self.fwd=tk.BooleanVar(value=True);ttk.Checkbutton(top,text='Forwarding',variable=self.fwd).pack(side='right')
        inputs=ttk.Frame(self,padding=8);inputs.pack(fill='x')
        for title,initial,width in [('MIPS programı',EXAMPLE,56),('Register başlangıcı','$s1=100\n$t3=5\n$t5=12',22),('Bellek başlangıcı','100=7',22)]:
            f=ttk.LabelFrame(inputs,text=title,padding=5);f.pack(side='left',fill='both',expand=True,padx=4)
            w=tk.Text(f,height=8,width=width,font=('Consolas',11));w.insert('1.0',initial);w.pack(fill='both',expand=True)
            if title.startswith('MIPS'):self.program=w
            elif title.startswith('Register'):self.registers=w
            else:self.memory=w
        bar=ttk.Frame(self,padding=8);bar.pack(fill='x')
        for label,action in [('Başlat/Sıfırla',self.reset),('◀ Geri',self.back),('İleri ▶',self.forward),('▶ Otomatik',self.autoplay),('■ Durdur',self.stop)]:ttk.Button(bar,text=label,command=action).pack(side='left',padx=4)
        self.status=ttk.Label(bar,text='Programı başlatın.');self.status.pack(side='right')
        canvasframe=ttk.LabelFrame(self,text='Datapath (kavramsal; aktif aşamalar renkli)',padding=5);canvasframe.pack(fill='x',padx=10)
        self.canvas=tk.Canvas(canvasframe,height=160,bg='white',highlightthickness=0);self.canvas.pack(fill='x')
        self.draw([])
        lower=ttk.Panedwindow(self,orient='horizontal');lower.pack(fill='both',expand=True,padx=10,pady=8)
        left=ttk.LabelFrame(lower,text='Çevrim geçmişi');right=ttk.LabelFrame(lower,text='Register / bellek / kontrol olayları');lower.add(left,weight=3);lower.add(right,weight=2)
        cols=('cycle','IF','ID','EX','MEM','WB');self.table=ttk.Treeview(left,columns=cols,show='headings',height=12)
        for col in cols:self.table.heading(col,text=col);self.table.column(col,width=65 if col=='cycle' else 150,stretch=True)
        self.table.pack(fill='both',expand=True)
        self.details=tk.Text(right,font=('Consolas',10),wrap='word');self.details.pack(fill='both',expand=True)
        self.reset()
    def parse_values(self,widget):
        out={}
        for line in widget.get('1.0','end').splitlines():
            line=line.split('#')[0].strip()
            if not line:continue
            k,v=line.split('=',1);out[k.strip()]=int(v.strip(),0)
        return out
    def reset(self):
        self.stop()
        try:self.sim=Pipeline(self.program.get('1.0','end'),self.parse_values(self.registers),self.parse_values(self.memory),self.fwd.get())
        except Exception as e:messagebox.showerror('Program hatası',str(e));return
        self.pos=0;self.refresh()
    def forward(self):
        if not self.sim:return
        if self.pos<len(self.sim.history)-1:self.pos+=1
        elif self.sim.step():self.pos+=1
        self.refresh()
    def back(self):
        self.pos=max(0,self.pos-1);self.refresh()
    def stop(self):self.running=False
    def autoplay(self):
        if self.running:return
        self.running=True;self.tick()
    def tick(self):
        if not self.running:return
        if self.pos==len(self.sim.history)-1 and self.sim.done():self.running=False;return
        self.forward();self.after(650,self.tick)
    def draw(self,active):
        c=self.canvas;c.delete('all');w=max(c.winfo_width(),1050)
        blocks=[('PC / IM','IF','#cfe5ff'),('IF/ID','ID','#d7f5dc'),('Register File','ID','#d7f5dc'),('ID/EX','EX','#ffe1bc'),('ALU / MUX','EX','#ffe1bc'),('EX/MEM','MEM','#e9d9ff'),('Data Memory','MEM','#e9d9ff'),('MEM/WB','WB','#ffcdd2'),('Write Back','WB','#ffcdd2')]
        step=(w-30)/len(blocks)
        for n,(name,stage,color) in enumerate(blocks):
            x=15+n*step;y=43;on=stage in active
            c.create_rectangle(x,y,x+step-8,y+70,fill=color if on else '#f1f5f9',outline='#2563eb' if on else '#a1aab7',width=3 if on else 1)
            c.create_text(x+(step-8)/2,y+27,text=name,font=('Arial',9,'bold'),width=step-14)
            c.create_text(x+(step-8)/2,y+53,text=stage,font=('Arial',9))
            if n<len(blocks)-1:c.create_line(x+step-8,y+35,x+step-1,y+35,arrow='last',fill='#e18a00' if on else '#999',width=2)
        c.create_text(w/2,17,text='Aktif veri yolu: mavi IF · yeşil ID · turuncu EX · mor MEM · kırmızı WB',font=('Arial',11))
    def refresh(self):
        if not self.sim:return
        s=self.sim.history[self.pos]
        self.status.configure(text=f'Çevrim {s["cycle"]} | Tamamlanan {s["completed"]} | Stall {s["stalls"]} | Flush {s["flushes"]} | CPI {s["cycle"]/s["completed"]:.2f}' if s['completed'] else f'Çevrim {s["cycle"]} | Henüz komut tamamlanmadı')
        for row in self.table.get_children():self.table.delete(row)
        for h in self.sim.history[:self.pos+1]:self.table.insert('', 'end',values=[h[k] for k in ('cycle','IF','ID','EX','MEM','WB')])
        self.draw([k for k in ('IF','ID','EX','MEM','WB') if s[k]!='—'])
        regs='\n'.join(f'${i:02d} = {v}' for i,v in enumerate(s['regs']) if v!=0)
        mem='\n'.join(f'[{k}] = {v}' for k,v in sorted(s['mem'].items()))
        self.details.delete('1.0','end');self.details.insert('end',f'PC (komut indeksi): {s["pc"]}\n\nOlaylar:\n{s["event"]}\n\nREGISTER FILE:\n{regs or "Tümü sıfır"}\n\nDATA MEMORY:\n{mem or "Boş"}\n\nNot: Geri düğmesi geçmiş durumları gösterir; sonraki ileri hareket kayıtlı geçmişi oynatır.')
        self.canvas.bind('<Configure>',lambda e:self.draw([k for k in ('IF','ID','EX','MEM','WB') if self.sim.history[self.pos][k]!='—']))
if __name__=='__main__':App().mainloop()
