import unittest
from simulator import Pipeline,reg
class Tests(unittest.TestCase):
 def test_alu(self):
  s=Pipeline('add $t0,$t1,$t2\nsub $t3,$t0,$t2\nand $t4,$t3,$t1',{'$t1':15,'$t2':7});s.run()
  self.assertEqual((s.regs[reg('t0')],s.regs[reg('t3')],s.regs[reg('t4')]),(22,15,15))
 def test_load_use(self):
  s=Pipeline('lw $t0,0($s1)\nadd $t2,$t0,$t3',{'$s1':100,'$t3':5},{100:7});s.run()
  self.assertEqual(s.regs[reg('t2')],12);self.assertEqual(s.stalls,1)
 def test_store(self):
  s=Pipeline('addi $t0,$zero,42\nsw $t0,4($s1)\nlw $t2,4($s1)',{'$s1':100});s.run()
  self.assertEqual(s.mem[104],42);self.assertEqual(s.regs[reg('t2')],42)
 def test_no_forward(self):
  s=Pipeline('add $t0,$t1,$t2\nsub $t3,$t0,$t2',{'$t1':15,'$t2':7},forwarding=False);s.run()
  self.assertEqual(s.regs[reg('t3')],15);self.assertGreaterEqual(s.stalls,2)
 def test_branch(self):
  s=Pipeline('addi $t0,$zero,1\nbeq $t0,$t0,SKIP\naddi $t1,$zero,99\nSKIP: addi $t2,$zero,7');s.run()
  self.assertEqual(s.regs[reg('t1')],0);self.assertEqual(s.regs[reg('t2')],7)
if __name__=='__main__':unittest.main()
