# MIPS Görsel Pipeline — Aşama 3

Bu uygulama Windows 10/11 ve Ubuntu 22.04/24.04 için ortak Python 3.10+ kaynak koduyla hazırlanmıştır. Tkinter grafik arayüzü kullanır.

## Ubuntu

```bash
sudo apt update
sudo apt install -y python3 python3-tk
cd mips_stage3
python3 -m unittest -v test_simulator.py
python3 app.py
```

## Windows

Python 3.10+ yükleyin (kurulumda PATH seçeneğini etkinleştirin). ZIP'i açın; klasörde PowerShell açıp:

```powershell
py -3 -m unittest -v test_simulator.py
py -3 app.py
```

Alternatif: `Baslat_Windows.bat` dosyasına çift tıklayın.

## Öğrenci kullanım adımları

1. Soldaki editöre MIPS komutlarını girin.
2. Register başlangıçlarını `$s1=100` biçiminde, bellek başlangıçlarını `100=7` biçiminde yazın.
3. Forwarding kutusunu seçin veya kaldırın.
4. **Başlat/Sıfırla** düğmesine basın.
5. **İleri** ile bir çevrim ilerleyin; **Geri** ile önceki kayıtlı çevrimi görüntüleyin.
6. **Otomatik** animasyonu başlatır, **Durdur** durdurur.
7. Alttaki tabloda aşamaları, sağdaki panelde register/bellek değişimlerini ve forwarding olaylarını inceleyin.
8. Forwarding'i kapatıp yeniden başlatın; stall ve toplam çevrimleri karşılaştırın.

## Deney 1 — ALU

```mips
add $t0,$t1,$t2
sub $t3,$t0,$t4
and $t5,$t3,$t6
```

Register başlangıcı: `$t1=15`, `$t2=25`, `$t4=10`, `$t6=7`.
Beklenen: `$t0=40`, `$t3=30`, `$t5=6`.

## Deney 2 — Load-use

```mips
lw $t0,0($s1)
add $t2,$t0,$t3
sub $t4,$t2,$t5
```

Register: `$s1=100`, `$t3=5`, `$t5=12`; bellek: `100=7`.
Beklenen: `$t0=7`, `$t2=12`, `$t4=0`. Forwarding açıkken load-use için bir stall beklenir.

## Deney 3 — Bellek

```mips
addi $t0,$zero,42
sw $t0,4($s1)
lw $t2,4($s1)
```

Register: `$s1=100`. Beklenen: bellek `[104]=42`, `$t2=42`.

## Kapsam ve sınırlamalar

- Desteklenen komutlar: `add`, `sub`, `and`, `or`, `addi`, `lw`, `sw`, `beq`, `nop`.
- `beq` EX aşamasında çözülür; varsayılan tahmin **not taken**'dır. Dinamik branch predictor henüz yoktur.
- Pipeline çizimi kavramsaldır; tüm transistor, kablo ve kontrol bitlerini modellemez.
- Komut adresleri 0 tabanlı **komut indeksleri** olarak gösterilir, gerçek byte adresleri değildir.
- Bellek eğitim amaçlı sözlükle modellenir; cache, alignment exception, overflow exception ve tam MIPS ISA yoktur.
- Geri alma, kaydedilmiş anlık görüntüleri gösterir; simülasyon geçmişini değiştirmez.
- Windows/Ubuntu masaüstünde grafik arayüz çalışması bu ortamda doğrudan test edilmemiştir; Python otomatik testleri çalıştırılmıştır.
