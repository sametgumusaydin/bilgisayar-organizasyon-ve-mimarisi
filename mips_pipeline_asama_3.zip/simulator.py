import re
from dataclasses import dataclass

REGS = {'zero':0,'at':1,'v0':2,'v1':3,'a0':4,'a1':5,'a2':6,'a3':7,
        **{f't{i}':8+i for i in range(8)}, **{f's{i}':16+i for i in range(8)},
        't8':24,'t9':25,'sp':29,'ra':31}

def reg(s):
    s=s.strip().lstrip('$').lower()
    if s.isdigit() and 0<=int(s)<32:return int(s)
    if s not in REGS:raise ValueError(f'Bilinmeyen register: {s}')
    return REGS[s]

def signed32(v):
    v=int(v)&0xffffffff
    return v-(1<<32) if v&0x80000000 else v

@dataclass
class Instr:
    op:str
    a:int=0
    b:int=0
    c:int=0
    text:str=''
    pc:int=0
    def sources(self):
        if self.op in ('add','sub','and','or'):return [self.b,self.c]
        if self.op in ('addi','lw'):return [self.b]
        if self.op=='sw':return [self.a,self.b]
        if self.op=='beq':return [self.a,self.b]
        return []
    def dest(self):return self.a if self.op in ('add','sub','and','or','addi','lw') else None


def parse(src):
    lines=[];labels={}
    for line in src.splitlines():
        line=line.split('#')[0].strip()
        if not line:continue
        while ':' in line:
            label,line=line.split(':',1);label=label.strip()
            if not re.fullmatch(r'[A-Za-z_]\w*',label):raise ValueError('Geçersiz etiket')
            if label in labels:raise ValueError('Tekrarlanan etiket: '+label)
            labels[label]=len(lines);line=line.strip()
        if line:lines.append(line)
    result=[]
    for pc,line in enumerate(lines):
        parts=[x for x in re.split(r'[\s,()]+',line) if x]
        op=parts[0].lower(); p=parts[1:]
        try:
            if op in ('add','sub','and','or') and len(p)==3: ins=Instr(op,reg(p[0]),reg(p[1]),reg(p[2]),line,pc)
            elif op=='addi' and len(p)==3: ins=Instr(op,reg(p[0]),reg(p[1]),int(p[2],0),line,pc)
            elif op in ('lw','sw') and len(p)==3: ins=Instr(op,reg(p[0]),reg(p[2]),int(p[1],0),line,pc)
            elif op=='beq' and len(p)==3: ins=Instr(op,reg(p[0]),reg(p[1]),labels[p[2]] if p[2] in labels else int(p[2],0),line,pc)
            elif op=='nop' and not p: ins=Instr(op,text=line,pc=pc)
            else:raise ValueError('Desteklenmeyen komut veya operand sayısı')
        except ValueError as e:raise ValueError(f'Satır/komut {pc+1}: {line} ({e})') from e
        result.append(ins)
    return result

class Pipeline:
    def __init__(self,code,initial_regs=None,initial_mem=None,forwarding=True):
        self.code=parse(code);self.regs=[0]*32;self.mem={};self.forwarding=forwarding
        for k,v in (initial_regs or {}).items():
            r=reg(k)
            if r:self.regs[r]=signed32(v)
        for k,v in (initial_mem or {}).items():self.mem[int(k)]=signed32(v)
        self.pc=0;self.cycle=0;self.completed=0;self.stalls=0;self.flushes=0
        self.IF_ID=None;self.ID_EX=None;self.EX_MEM=None;self.MEM_WB=None
        self.log=[];self.history=[]
        self.snapshot('Başlangıç')
    def snapshot(self,event):
        def show(x):return x['i'].text if x else '—'
        self.history.append({'cycle':self.cycle,'IF':self.code[self.pc].text if self.pc<len(self.code) else '—',
             'ID':show(self.IF_ID),'EX':show(self.ID_EX),'MEM':show(self.EX_MEM),'WB':show(self.MEM_WB),
             'event':event,'regs':self.regs[:],'mem':self.mem.copy(),'pc':self.pc,'completed':self.completed,
             'stalls':self.stalls,'flushes':self.flushes})
    def done(self):return self.pc>=len(self.code) and all(x is None for x in (self.IF_ID,self.ID_EX,self.EX_MEM,self.MEM_WB))
    def step(self):
        if self.done():return False
        self.cycle+=1;events=[]
        wb=self.MEM_WB; mem=self.EX_MEM; ex=self.ID_EX; dec=self.IF_ID
        # WB register write, visible to ID at this cycle's end
        if wb:
            i=wb['i']; d=i.dest()
            if d is not None and d!=0:self.regs[d]=signed32(wb['value']);events.append(f'WB ${d}={self.regs[d]}')
            self.completed+=1
        # MEM
        next_wb=None
        if mem:
            i=mem['i'];value=mem['alu']
            if i.op=='lw':value=self.mem.get(mem['alu'],0);events.append(f'MEM okuma [{mem["alu"]}]={value}')
            if i.op=='sw':self.mem[mem['alu']]=mem['store'];events.append(f'MEM yazma [{mem["alu"]}]={mem["store"]}')
            next_wb={'i':i,'value':value}
        # EX forwarding from previous EX/MEM or MEM/WB
        next_mem=None;branch=False;target=None
        if ex:
            i=ex['i'];vals={r:v for r,v in ex['read'].items()}
            for r in i.sources():
                if self.forwarding and mem and mem['i'].dest()==r and r!=0 and mem['i'].op!='lw':
                    vals[r]=mem['alu'];events.append(f'Forward EX/MEM → EX (${r})')
                elif self.forwarding and wb and wb['i'].dest()==r and r!=0:
                    vals[r]=wb['value'];events.append(f'Forward MEM/WB → EX (${r})')
            a=vals.get(i.b,0); b=vals.get(i.c,0)
            if i.op=='add':alu=signed32(a+b)
            elif i.op=='sub':alu=signed32(a-b)
            elif i.op=='and':alu=signed32(a&b)
            elif i.op=='or':alu=signed32(a|b)
            elif i.op=='addi':alu=signed32(a+i.c)
            elif i.op in ('lw','sw'):alu=signed32(a+i.c)
            elif i.op=='beq':
                alu=0;branch=vals.get(i.a,0)==vals.get(i.b,0);target=i.c
            else:alu=0
            next_mem={'i':i,'alu':alu,'store':vals.get(i.a,0)}
            events.append(f'EX {i.text}: ALU={alu}')
        # stall when ID uses a pending register that cannot be read correctly
        stall=False
        if dec and not branch:
            src=set(dec['i'].sources())-{0}
            if self.forwarding:
                stall=bool(ex and ex['i'].op=='lw' and ex['i'].dest() in src)
            else:
                stall=any(stage and stage['i'].dest() in src for stage in (ex,mem))
        next_ex=None;next_id=None
        if branch:
            # branch resolved in EX; squash IF/ID and next fetch
            self.pc=target;self.flushes+=int(dec is not None)+int(self.pc_before_fetch_valid())
            events.append(f'Branch TAKEN → PC={target}; yanlış yol iptal')
        elif stall:
            self.stalls+=1;next_id=dec;events.append('STALL: ID bekliyor, EX bubble')
        else:
            if dec:
                i=dec['i'];next_ex={'i':i,'read':{r:self.regs[r] for r in i.sources()}}
            if self.pc<len(self.code):next_id={'i':self.code[self.pc]};self.pc+=1
        self.MEM_WB=next_wb;self.EX_MEM=next_mem;self.ID_EX=next_ex;self.IF_ID=next_id
        self.regs[0]=0;self.snapshot(' | '.join(events) if events else 'Normal ilerleme')
        return True
    def pc_before_fetch_valid(self):return self.pc<len(self.code)
    def run(self,limit=500):
        for _ in range(limit):
            if not self.step():return
        raise RuntimeError('Çevrim sınırı aşıldı; sonsuz döngü olabilir')
