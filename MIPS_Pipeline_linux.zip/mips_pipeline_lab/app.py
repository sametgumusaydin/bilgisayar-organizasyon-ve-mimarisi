import tkinter as tk
from tkinter import ttk,messagebox
from simulator import Simulator
root=tk.Tk();root.title('MIPS 5-Stage Pipeline Laboratuvarı');root.geometry('1150x780')
top=ttk.Frame(root,padding=8);top.pack(fill='x')
ttk.Label(top,text='MIPS Programı').grid(row=0,column=0,sticky='w');ttk.Label(top,text='Başlangıç register değerleri').grid(row=0,column=1,sticky='w');ttk.Label(top,text='Bellek (adres=değer)').grid(row=0,column=2,sticky='w')
code=tk.Text(top,width=48,height=12);code.grid(row=1,column=0,padx=5);code.insert('1.0','lw $t0, 0($s1)\nadd $t2, $t0, $t3\nsub $t4, $t2, $t5')
regs=tk.Text(top,width=27,height=12);regs.grid(row=1,column=1,padx=5);regs.insert('1.0','$s1=100\n$t3=5\n$t5=12')
mem=tk.Text(top,width=25,height=12);mem.grid(row=1,column=2,padx=5);mem.insert('1.0','100=7')
controls=ttk.Frame(root,padding=8);controls.pack(fill='x');fw=tk.BooleanVar(value=True);ttk.Checkbutton(controls,text='Forwarding açık',variable=fw).pack(side='left',padx=8)
ttk.Label(controls,text='Branch prediction:').pack(side='left');prediction=tk.StringVar(value='not_taken');ttk.Combobox(controls,textvariable=prediction,values=['not_taken','taken','two_bit'],state='readonly',width=14).pack(side='left',padx=5)
summary=tk.StringVar(value='Başlat ile simülasyonu oluşturun.');ttk.Label(root,textvariable=summary,padding=8).pack(anchor='w')
cols=['Cycle','IF','ID','EX','MEM','WB'];tree=ttk.Treeview(root,columns=cols,show='headings',height=17)
for col in cols:tree.heading(col,text=col);tree.column(col,width=72 if col=='Cycle' else 190,anchor='center')
tree.pack(fill='both',expand=True,padx=12,pady=6)
output=tk.Text(root,height=7);output.pack(fill='x',padx=12,pady=6)
sim=None
def update():
 if sim is None:return
 summary.set(f'Cycle: {sim.cycle}  |  Tamamlanan: {sim.retired}  |  Stall: {sim.stalls}  |  Flush edilen komut: {sim.flushes}  |  Yanlış tahmin: {sim.mispredictions}  |  CPI: {sim.cpi:.3f}')
 output.delete('1.0','end');output.insert('end','Register değerleri:\n'+', '.join(f'${i}={v}' for i,v in enumerate(sim.regs) if v and i!=0)+'\nBellek:\n'+str(sim.mem))
def start():
 global sim
 try:sim=Simulator(code.get('1.0','end'),regs.get('1.0','end'),mem.get('1.0','end'),fw.get(),prediction.get())
 except Exception as e:messagebox.showerror('Komut hatası',str(e));return
 for item in tree.get_children():tree.delete(item)
 update()
def step():
 if sim is None:start()
 if sim is None:return
 try:
  if sim.step():tree.insert('', 'end',values=[sim.cycle]+sim.history[-1]);tree.yview_moveto(1)
 except Exception as e:messagebox.showerror('Simülasyon hatası',str(e))
 update()
def run():
 if sim is None:start()
 if sim is None:return
 while not sim.done and sim.cycle<1000:step()
buttons=ttk.Frame(controls);buttons.pack(side='right');ttk.Button(buttons,text='Başlat / Sıfırla',command=start).pack(side='left',padx=4);ttk.Button(buttons,text='1 çevrim ilerle',command=step).pack(side='left',padx=4);ttk.Button(buttons,text='Tamamını çalıştır',command=run).pack(side='left',padx=4)
root.mainloop()
