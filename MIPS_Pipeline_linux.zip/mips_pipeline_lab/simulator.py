import re
REGS={'zero':0,'at':1,'v0':2,'v1':3,'a0':4,'a1':5,'a2':6,'a3':7,'t0':8,'t1':9,'t2':10,'t3':11,'t4':12,'t5':13,'t6':14,'t7':15,'s0':16,'s1':17,'s2':18,'s3':19,'s4':20,'s5':21,'s6':22,'s7':23,'t8':24,'t9':25,'sp':29,'ra':31}
def reg(s):
 s=s.strip().lstrip('$'); return int(s) if s.isdigit() and 0<=int(s)<32 else REGS[s]
def parse(source):
 lines=[]; labels={}
 for raw in source.splitlines():
  line=raw.split('#')[0].strip()
  if not line: continue
  while ':' in line:
   label,line=line.split(':',1); labels[label.strip()]=len(lines); line=line.strip()
  if line: lines.append(line)
 result=[]
 for line in lines:
  parts=[x for x in re.split(r'[\s,()]+',line) if x]; op=parts[0].lower(); a=parts[1:]; ins={'op':op,'text':line}
  if op in ('add','sub','and','or'): ins.update(dst=reg(a[0]),src=[reg(a[1]),reg(a[2])])
  elif op=='addi': ins.update(dst=reg(a[0]),src=[reg(a[1])],imm=int(a[2],0))
  elif op=='lw': ins.update(dst=reg(a[0]),src=[reg(a[2])],imm=int(a[1],0))
  elif op=='sw': ins.update(dst=None,src=[reg(a[2]),reg(a[0])],imm=int(a[1],0))
  elif op=='beq': ins.update(dst=None,src=[reg(a[0]),reg(a[1])],target=labels[a[2]] if a[2] in labels else int(a[2],0))
  elif op=='nop': ins.update(dst=None,src=[])
  else: raise ValueError('Desteklenmeyen komut: '+op)
  result.append(ins)
 return result
class Simulator:
 def __init__(self,source,registers='',memory='',forwarding=True,prediction='not_taken'):
  self.code=parse(source); self.regs=[0]*32; self.mem={}; self.forwarding=forwarding; self.prediction=prediction
  for text,dest in ((registers,self.regs),(memory,self.mem)):
   for item in re.split(r'[,\n]+',text):
    if not item.strip():continue
    k,v=item.split('=',1); k=k.strip(); v=int(v.strip(),0)
    if isinstance(dest,list): dest[reg(k)]=v
    else: dest[int(k,0)]=v
  self.pc=0; self.stages=[None]*5; self.cycle=0; self.retired=0; self.stalls=0; self.flushes=0; self.mispredictions=0; self.branch_state=1; self.history=[]
 def predict(self,pc,ins):
  if ins['op']!='beq':return pc+1
  taken=self.prediction=='taken' or (self.prediction=='two_bit' and self.branch_state>=2)
  return ins['target'] if taken else pc+1
 def value(self,r,old):
  if r==0:return 0
  if self.forwarding:
   for index in (2,3):
    e=old[index]
    if e and e['ins'].get('dst')==r and e['ins']['op']!='lw' and e.get('result') is not None:return e['result']
   e=old[3]
   if e and e['ins'].get('dst')==r and e.get('result') is not None:return e['result']
  return self.regs[r]
 def step(self):
  if self.done:return False
  old=self.stages; self.cycle+=1; new=[None]*5
  wb=old[4]
  if wb:
   if wb['ins'].get('dst') not in (None,0):self.regs[wb['ins']['dst']]=wb['result']
   self.retired+=1
  mem=old[3]
  if mem:
   e=dict(mem); op=e['ins']['op']
   if op=='lw':e['result']=self.mem.get(e['address'],0)
   elif op=='sw':self.mem[e['address']]=e['store']
   new[4]=e
  ex=old[2]; redirect=None
  if ex:
   e=dict(ex); ins=e['ins']; op=ins['op']; src=ins.get('src',[]); v=[self.value(r,old) for r in src]
   if op=='add':e['result']=v[0]+v[1]
   elif op=='sub':e['result']=v[0]-v[1]
   elif op=='and':e['result']=v[0]&v[1]
   elif op=='or':e['result']=v[0]|v[1]
   elif op=='addi':e['result']=v[0]+ins['imm']
   elif op in ('lw','sw'):
    e['address']=v[0]+ins['imm']
    if op=='sw':e['store']=v[1]
   elif op=='beq':
    taken=v[0]==v[1]; actual=ins['target'] if taken else e['pc']+1
    if self.prediction=='two_bit':self.branch_state=min(3,self.branch_state+1) if taken else max(0,self.branch_state-1)
    if actual!=e['predicted']:redirect=actual; self.mispredictions+=1
   new[3]=e
  idstage=old[1]; hazard=False
  if idstage:
   needed=idstage['ins'].get('src',[])
   for idx in ((2,) if self.forwarding else (2,3)):
    producer=old[idx]
    if producer and producer['ins'].get('dst') not in (None,0) and producer['ins']['dst'] in needed:
     if not self.forwarding or producer['ins']['op']=='lw':hazard=True
   if not hazard:new[2]=idstage
  if redirect is not None:
   self.pc=redirect; self.flushes+=sum(x is not None for x in old[:2]); hazard=False; new[2]=None; new[1]=None; new[0]=None
  elif hazard:
   self.stalls+=1;new[1]=old[1];new[0]=old[0]
  else:
   new[1]=old[0]
  if redirect is None and not hazard and 0<=self.pc<len(self.code):
   ins=self.code[self.pc]; predicted=self.predict(self.pc,ins);new[0]={'ins':ins,'pc':self.pc,'predicted':predicted};self.pc=predicted
  self.stages=new
  self.history.append([s['ins']['text'] if s else '—' for s in new])
  if self.cycle>1000:raise RuntimeError('1000 çevrim sınırı: olası sonsuz döngü')
  return True
 @property
 def done(self):return not (0<=self.pc<len(self.code)) and all(s is None for s in self.stages)
 def run(self):
  while not self.done:self.step()
  return self
 @property
 def cpi(self):return self.cycle/self.retired if self.retired else 0
