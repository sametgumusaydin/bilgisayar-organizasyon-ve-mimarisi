import unittest
from simulator import Simulator
class Tests(unittest.TestCase):
 def test_arithmetic(self):
  s=Simulator('add $t0,$t1,$t2\nsub $t3,$t0,$t4','$t1=15\n$t2=25\n$t4=10').run();self.assertEqual(s.regs[8],40);self.assertEqual(s.regs[11],30)
 def test_load_hazard(self):
  s=Simulator('lw $t0,0($s1)\nadd $t2,$t0,$t3','$s1=100\n$t3=5','100=7').run();self.assertEqual(s.regs[10],12);self.assertEqual(s.stalls,1)
 def test_no_forwarding(self):
  s=Simulator('add $t0,$t1,$t2\nsub $t3,$t0,$t4','$t1=15\n$t2=25\n$t4=10',forwarding=False).run();self.assertEqual(s.regs[11],30);self.assertGreater(s.stalls,0)
 def test_branch(self):
  s=Simulator('addi $t0,$zero,1\nbeq $t0,$t0,TARGET\naddi $t1,$zero,99\nTARGET: addi $t2,$zero,7').run();self.assertEqual(s.regs[9],0);self.assertEqual(s.regs[10],7);self.assertEqual(s.mispredictions,1)
if __name__=='__main__':unittest.main()
