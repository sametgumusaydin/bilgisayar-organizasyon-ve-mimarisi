# MIPS Pipeline Laboratuvarı (Ubuntu)

## Kurulum

```bash
sudo apt update
sudo apt install -y python3 python3-tk
cd mips_pipeline_lab
python3 -m unittest -v test_simulator.py
python3 app.py
```

Harici Python paketi gerekmez. Ubuntu 22.04 ve Python 3.10+ hedeflenmiştir.

## Deney 1 — ALU ve datapath

```mips
add $t0,$t1,$t2
sub $t3,$t0,$t4
```

Register başlangıcı: `$t1=15`, `$t2=25`, `$t4=10`.
Beklenen: `$t0=40`, `$t3=30`.

## Deney 2 — Load-use hazard

```mips
lw $t0,0($s1)
add $t2,$t0,$t3
sub $t4,$t2,$t5
```

Register başlangıcı: `$s1=100`, `$t3=5`, `$t5=12`. Bellek: `100=7`.
Forwarding açıkken load-use için 1 stall beklenir. Forwarding kapalıyken daha fazla stall gözlenir.

## Deney 3 — Branch prediction

```mips
addi $t0,$zero,1
beq $t0,$t0,TARGET
addi $t1,$zero,99
TARGET: addi $t2,$zero,7
```

`not_taken`, `taken`, `two_bit` seçeneklerini deneyin. Beklenen: `$t1=0`, `$t2=7`.

## Eğitim modeli ve sınırlamalar

Bu uygulama öğretim amaçlı, sıralı, tek komut genişlikli, 5 aşamalı MIPS benzeri bir modeldir. Gerçek MIPS ISA'nın tüm komutlarını ve bellek zamanlamasını modellemez. IF/ID/EX/MEM/WB çevrimlerini ve basit hazard/forwarding mekanizmasını gösterir. Bellek adresleri sayısal anahtarlar olarak tutulur; cache, istisnalar, byte adresleme, overflow, branch delay slot ve gerçek donanım gecikmeleri modellenmez. Dallanma EX aşamasında çözümlenir. Sonuçlar eğitim modeline göredir.
