# MIPS Görsel Pipeline — Aşama 2

Windows 10/11 ve Ubuntu 22.04/24.04 için ortak Tkinter uygulaması. Python 3.10+ gerekir.

## Ubuntu kurulumu

```bash
sudo apt update
sudo apt install -y python3 python3-tk unzip
cd MIPS_Visual_Pipeline_Asama2
python3 app.py
```

## Windows kurulumu

Python'u https://www.python.org/downloads/ adresinden yükleyin (kurulumda PATH seçeneğini etkinleştirin). ZIP'i çıkarın ve `Baslat_Windows.bat` dosyasına çift tıklayın. Alternatif:

```powershell
py -3 app.py
```

## Öğrenci yönergesi

1. `Load-use hazard` örneğini seçin.
2. `İleri` ile her çevrimde IF/ID/EX/MEM/WB aşamalarını izleyin.
3. Forwarding seçeneğini kapatın ve `Sıfırla` düğmesine basın.
4. Stall sayısını ve CPI değerini karşılaştırın.
5. `ALU bağımlılığı` örneğinde aynı işlemi tekrarlayın.
6. Sonuçlarınızı tablo halinde raporlayın; forwarding'in hangi RAW bağımlılıklarını azaltabildiğini açıklayın.

## Kapsam ve sınırlamalar

Bu, Aşama 2'nin **kavramsal görsel eğitim modeli**dir. Çevrim çizelgesi temel RAW bağımlılıklarını ve stall etkisini gösterir. Komutların gerçek sayısal sonuçları, branch prediction, flush, ayrıntılı forwarding kontrol hatları ve tüm MIPS ISA davranışı bu sürümde yoktur. Zaman çizelgesindeki gecikmeler, tek komutlu sıralı beş aşamalı model için basitleştirilmiştir. Şema kitabın birebir kopyası değildir.
