import tkinter as tk
from tkinter import ttk, messagebox

STAGES = ['IF', 'ID', 'EX', 'MEM', 'WB']
EXAMPLES = {
    'ALU bağımlılığı': ['add $t0,$t1,$t2', 'sub $t3,$t0,$t4', 'and $t5,$t3,$t6'],
    'Load-use hazard': ['lw $t0,0($s1)', 'add $t2,$t0,$t3', 'sub $t4,$t2,$t5'],
    'Bağımsız komutlar': ['add $t0,$t1,$t2', 'or $t3,$t4,$t5', 'sub $t6,$t7,$t8'],
}

def operands(line):
    s=line.replace(',', ' ').replace('(', ' ').replace(')', ' ').split()
    op=s[0].lower() if s else ''
    if op=='lw': return op, s[1] if len(s)>1 else '', [s[3]] if len(s)>3 else []
    if op=='sw': return op, '', [s[1],s[3]] if len(s)>3 else []
    if op in ('add','sub','and','or','slt'): return op, s[1] if len(s)>1 else '', s[2:4]
    if op=='addi': return op, s[1] if len(s)>1 else '', s[2:3]
    if op=='beq': return op, '', s[1:3]
    return op,'',[]

def schedule(lines, forwarding):
    # Simple in-order five-stage educational timing model, no branch execution.
    rows=[]; stalls=0
    for i,line in enumerate(lines):
        op,dst,src=operands(line)
        start= i+1+stalls
        while True:
            id_cycle=start+1; ex_cycle=start+2
            conflict=False
            for p in rows:
                if p['dst'] and p['dst'] in src:
                    if forwarding:
                        ready=p['mem']+1 if p['op']=='lw' else p['ex']+1
                        if ex_cycle<ready: conflict=True
                    else:
                        if id_cycle<p['wb']: conflict=True
            if not conflict: break
            start+=1; stalls+=1
        rows.append(dict(line=line,op=op,dst=dst,src=src,start=start,ex=start+2,mem=start+3,wb=start+4))
    return rows,stalls

class App(tk.Tk):
    def __init__(self):
        super().__init__(); self.title('MIPS Visual Pipeline — Aşama 2 (Windows / Ubuntu)'); self.geometry('1160x790')
        self.forward=tk.BooleanVar(value=True); self.example=tk.StringVar(value='Load-use hazard')
        top=ttk.Frame(self,padding=8); top.pack(fill='x')
        ttk.Label(top,text='Örnek:').pack(side='left'); combo=ttk.Combobox(top,textvariable=self.example,values=list(EXAMPLES),state='readonly',width=23); combo.pack(side='left',padx=5); combo.bind('<<ComboboxSelected>>',lambda e:self.load_example())
        ttk.Checkbutton(top,text='Forwarding',variable=self.forward,command=self.reset).pack(side='left',padx=15)
        ttk.Button(top,text='Sıfırla',command=self.reset).pack(side='left'); ttk.Button(top,text='◀ Geri',command=self.back).pack(side='left',padx=5); ttk.Button(top,text='İleri ▶',command=self.next).pack(side='left'); ttk.Button(top,text='▶ Oynat / Durdur',command=self.toggle).pack(side='left',padx=5)
        self.info=ttk.Label(top,text='');self.info.pack(side='right')
        ttk.Label(self,text='MIPS komutları (bir satıra bir komut):').pack(anchor='w',padx=10)
        self.editor=tk.Text(self,height=5,font=('DejaVu Sans Mono',11));self.editor.pack(fill='x',padx=10)
        ttk.Button(self,text='Komutları uygula',command=self.reset).pack(anchor='w',padx=10,pady=5)
        self.canvas=tk.Canvas(self,bg='#f8fafc',height=350,highlightthickness=1,highlightbackground='#ccd5e0');self.canvas.pack(fill='both',expand=True,padx=10,pady=5)
        self.table=tk.Text(self,height=11,font=('DejaVu Sans Mono',10),state='disabled',bg='#f4f7fa');self.table.pack(fill='x',padx=10,pady=8)
        self.cycle=0;self.running=False;self.rows=[];self.load_example()
    def load_example(self):
        self.editor.delete('1.0','end');self.editor.insert('1.0','\n'.join(EXAMPLES[self.example.get()]));self.reset()
    def reset(self):
        lines=[x.strip() for x in self.editor.get('1.0','end').splitlines() if x.strip() and not x.strip().startswith('#')]
        if len(lines)>20: messagebox.showwarning('Sınır','En fazla 20 komut girin.');return
        self.rows,self.stalls=schedule(lines,self.forward.get());self.cycle=0;self.running=False;self.draw()
    def next(self): self.cycle=min(self.cycle+1,max([r['wb'] for r in self.rows],default=0));self.draw()
    def back(self): self.cycle=max(0,self.cycle-1);self.draw()
    def toggle(self):
        self.running=not self.running
        if self.running:self.tick()
    def tick(self):
        if not self.running:return
        if self.cycle>=max([r['wb'] for r in self.rows],default=0):self.running=False;return
        self.next();self.after(850,self.tick)
    def draw(self):
        c=self.canvas;c.delete('all');w=max(c.winfo_width(),1050);h=max(c.winfo_height(),350)
        names=['PC','Instruction\nMemory','IF/ID','Register\nFile','Control\nUnit','ID/EX','ALU / MUX','EX/MEM','Data\nMemory','MEM/WB','Write Back']
        xs=[55,160,266,370,370,482,605,724,830,940,1050]
        stage_for=[0,0,0,1,1,1,2,2,3,3,4]
        active={}
        for r in self.rows:
            idx=self.cycle-r['start'];
            if 0<=idx<5:active[idx]=r['line']
        colors=['#bfdbfe','#bbf7d0','#fed7aa','#e9d5ff','#fecaca']
        for i,n in enumerate(names):
            x=xs[i]*w/1130; y=115 if i!=4 else 225; st=stage_for[i]; on=st in active
            c.create_rectangle(x-43,y-33,x+43,y+33,fill=colors[st] if on else '#e2e8f0',outline='#2563eb' if on else '#94a3b8',width=2)
            c.create_text(x,y,text=n,justify='center',font=('Arial',10,'bold'),fill='#172554')
            if i not in (4,10):
                nxt=xs[i+1]*w/1130; nx=x+43; end=nxt-43
                if end>nx: c.create_line(nx,115,end,115,arrow='last',fill='#ea580c' if on else '#94a3b8',width=3 if on else 1)
        c.create_line(xs[4]*w/1130,192,xs[4]*w/1130,149,arrow='last',fill='#64748b',width=2)
        c.create_text(w/2,28,text='Beş aşamalı MIPS datapath — kavramsal donanım görünümü',font=('Arial',16,'bold'),fill='#0f172a')
        for st,name in enumerate(STAGES):
            x=95+st*(w-190)/5;c.create_rectangle(x,285,x+(w-190)/5-8,330,fill=colors[st] if st in active else '#e2e8f0',outline='#94a3b8');c.create_text(x+((w-190)/5-8)/2,296,text=name,font=('Arial',10,'bold'));c.create_text(x+((w-190)/5-8)/2,313,text=(active.get(st,'—')[:22]),font=('Arial',9))
        last=max([r['wb'] for r in self.rows],default=0)
        self.info.config(text=f'Çevrim: {self.cycle}/{last} | Stall: {self.stalls} | CPI: {(last/len(self.rows)) if self.rows else 0:.2f}')
        maxcycle=min(last,24)
        header='Komut'.ljust(28)+''.join(f'{i:>5}' for i in range(1,maxcycle+1))+'\n'
        body=''
        for r in self.rows:
            seq=[]
            for cycle in range(1,maxcycle+1):
                d=cycle-r['start'];seq.append(STAGES[d] if 0<=d<5 else '')
            body+=r['line'][:27].ljust(28)+''.join(f'{v:>5}' for v in seq)+'\n'
        body+='\nNot: Bu aşama öğretim amaçlı zamanlama ve kavramsal datapath gösterir.\nBranch yürütme, register değerleri ve gerçek bypass sinyalleri Aşama 3 kapsamındadır.'
        self.table.config(state='normal');self.table.delete('1.0','end');self.table.insert('1.0',header+body);self.table.config(state='disabled')

if __name__=='__main__':
    app=App();app.after(150,app.draw);app.bind('<Configure>',lambda e:app.draw() if e.widget==app.canvas else None);app.mainloop()
