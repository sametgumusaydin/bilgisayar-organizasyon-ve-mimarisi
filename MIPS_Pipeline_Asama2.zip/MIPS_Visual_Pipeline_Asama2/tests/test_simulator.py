import unittest,sys,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
from simulator import simulate,parse
class TestPipeline(unittest.TestCase):
 def test_basic(self):
  p,s=simulate(['add $t0,$t1,$t2','sub $t3,$t4,$t5'])
  self.assertEqual(len(s)-1,6)
 def test_load_use(self):
  _,s=simulate(['lw $t0,0($s1)','add $t2,$t0,$t3'])
  self.assertEqual(s[-1]['stalls'],1)
 def test_forwarding_off(self):
  program=['add $t0,$t1,$t2','sub $t3,$t0,$t4']
  _,a=simulate(program,True);_,b=simulate(program,False)
  self.assertGreater(b[-1]['stalls'],a[-1]['stalls'])
 def test_store(self):
  self.assertEqual(parse('sw $t0,8($s1)')['src'],['$t0','$s1'])
 def test_bad(self):
  with self.assertRaises(ValueError):parse('multiply $t0,$t1,$t2')
if __name__=='__main__':unittest.main()
