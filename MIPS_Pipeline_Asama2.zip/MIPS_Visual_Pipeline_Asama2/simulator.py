"""Cycle-accurate *stage occupancy* teaching model (not an ISA emulator)."""
import re
STAGES=('IF','ID','EX','MEM','WB')
PAT=re.compile(r'^\s*(add|sub|and|or|lw|sw|beq)\s+(.+?)\s*$',re.I)
REG=r'\$[a-z][a-z0-9]*|\$zero'

def parse(line):
    m=PAT.fullmatch(line.strip())
    if not m: raise ValueError('Geçersiz komut: '+line)
    op=m.group(1).lower(); args=[a.strip().lower() for a in m.group(2).split(',')]
    if op in ('add','sub','and','or'):
        if len(args)!=3 or any(not re.fullmatch(REG,a) for a in args):raise ValueError('Register biçimi hatalı: '+line)
        return {'op':op,'dst':args[0],'src':args[1:],'text':line.strip()}
    if op in ('lw','sw'):
        if len(args)!=2:raise ValueError('Bellek operandı hatalı: '+line)
        mm=re.fullmatch(r'(-?\d+)\s*\(\s*('+REG+r')\s*\)',args[1])
        if not mm or not re.fullmatch(REG,args[0]):raise ValueError('Bellek adresi offset(base) olmalı: '+line)
        return {'op':op,'dst':args[0] if op=='lw' else None,'src':[mm.group(2)] if op=='lw' else [args[0],mm.group(2)],'text':line.strip()}
    if len(args)!=3 or not all(re.fullmatch(REG,a) for a in args[:2]) or not re.fullmatch(r'[A-Za-z_]\w*',args[2]):raise ValueError('beq biçimi: beq $t0,$t1,LABEL')
    return {'op':op,'dst':None,'src':args[:2],'text':line.strip()}

def simulate(lines, forwarding=True):
    instructions=[parse(s) for s in lines]
    if not instructions:raise ValueError('En az bir komut girin')
    if len(instructions)>30:raise ValueError('En fazla 30 komut')
    # Branches are displayed as datapath demonstrations, but are not executed.
    slots=[0,None,None,None,None]; pc=1; stalls=0; states=[]
    for cycle in range(250):
        states.append({'cycle':cycle,'slots':tuple(slots),'stalls':stalls,'stall':False,'forward':[]})
        if pc==len(instructions) and all(v is None for v in slots):break
        old=slots[:]; new=[None,old[0],old[1],old[2],old[3]]
        hazard=False; fw=[]
        consumer=old[1]
        if consumer is not None:
            src=instructions[consumer]['src']
            for stage in (2,3):
                producer=old[stage]
                if producer is None:continue
                instr=instructions[producer]; dst=instr['dst']
                if dst is None or dst=='$zero' or dst not in src:continue
                if not forwarding or (stage==2 and instr['op']=='lw'):
                    hazard=True;break
                fw.append((producer,consumer,stage))
        if hazard:
            stalls+=1;new[0]=old[0];new[1]=old[1];new[2]=None
        else:
            new[0]=pc if pc<len(instructions) else None
            if pc<len(instructions):pc+=1
        slots=new
        states[-1]['stall']=hazard
        states[-1]['forward']=fw
    else:raise RuntimeError('Simülasyon çevrim sınırını aştı')
    return instructions,states
