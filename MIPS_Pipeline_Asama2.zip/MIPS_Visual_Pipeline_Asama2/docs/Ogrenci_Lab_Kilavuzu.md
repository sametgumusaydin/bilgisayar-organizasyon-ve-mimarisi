# MIPS Görsel Pipeline Laboratuvarı — Aşama 2

**Ubuntu 22.04/24.04 ve Windows 10/11**, Python 3.10+, Tkinter. Harici Python paketi gerekmez.

## Ubuntu kurulumu

```bash
sudo apt update
sudo apt install -y python3 python3-tk
cd MIPS_Visual_Pipeline_Asama2
python3 -m unittest discover -s tests -v
python3 app.py
```

## Windows kurulumu

Python 3.10+ kurun (kurulumda PATH seçeneği önerilir). PowerShell'de:

```powershell
cd C:\MIPS_Visual_Pipeline_Asama2
py -3 -m unittest discover -s tests -v
py -3 app.py
```

Alternatif: `Baslat_Windows.bat` veya `Baslat_Ubuntu.sh`.

## Öğrenci kullanımı

1. **Deney** menüsünden bir örnek seçin.
2. **Programı yükle** ile komutları doğrulayın.
3. **İleri** düğmesine her basışta bir saat çevrimi ilerleyin; **Geri** ile önceki duruma dönün.
4. **Datapath odağı** bölümünde IF/ID/EX/MEM/WB seçerek o aşamanın aktif bileşenlerini ve bağlantılarını renklendirin.
5. **Forwarding** seçeneğini kapatıp açarak stall ve toplam çevrim sayısını karşılaştırın.
6. **Oynat** ile otomatik animasyonu başlatın, **Durdur** ile durdurun.
7. Alttaki tabloda komutların aşamalara dağılımını inceleyin.

### Deney 1: ALU forwarding

```mips
add $t0,$t1,$t2
sub $t3,$t0,$t4
and $t5,$t3,$t6
```

Forwarding açık ve kapalı toplam çevrimleri karşılaştırın. RAW bağımlılıklarını işaretleyin.

### Deney 2: Load-use hazard

```mips
lw $t0,0($s1)
add $t2,$t0,$t3
sub $t4,$t2,$t5
```

Forwarding açıkken bile ilk iki komut arasında neden bir stall gerektiğini açıklayın.

### Deney 3: Veri yolu keşfi

`sw $t0,8($s1)` ve `lw $t3,8($s1)` komutları için ALU'nun etkin adres hesaplamasını ve MEM aşamasının görevini açıklayın.

## Kapsam ve sınırlar

Bu sürüm **pipeline aşama yerleşimini ve kavramsal datapath yollarını** görselleştirir; gerçek register/bellek değerlerini hesaplamaz. Seçilen odak aşaması, aynı çevrimde o aşamada komut bulunmasa da donanım yolunu gösterir. Çizim kitaptan kopya değil, özgün öğretim şemasıdır. `beq` sözdizimi kabul edilir fakat branch yönlendirmesi, flush ve branch prediction **henüz uygulanmaz**. Branch komutlu örnekler performans analizi için kullanılmamalıdır. İleri seviye store-data forwarding ve kesin MIPS ISA zamanlaması modellenmemiştir. CPI toplam çevrim / komut sayısı olarak hesaplanır ve yalnızca program bittiğinde anlamlıdır.
